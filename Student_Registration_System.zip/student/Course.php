<html>
<head>
 <title>Registration Form</title>
</head>
<body>
<?php if (isset($_GET['form_submitted'])){
//this code is executed when the form is submitted
?>
<h2>Thank You <?php echo "Course Registration from"; ?>
</h2>
<p>You have been registered as
 <?php echo "<br />"; ?>
 <?php echo "Course_code : " . $_GET['Course_code'];?>
 <?php echo "<br />"; ?>
 <?php echo "Course_Title : " . $_GET['Course_Title'];?>
 <?php echo "<br />"; ?>
 <?php echo "Credit_hour : " . $_GET['Credit_hour'];?>
 <?php
 $username = 'root';
 $password = '';
 try {
 $conn = new
PDO("mysql:host=localhost;dbname=admission", $username,
$password);
// set the PDO error mode to exception
 $conn->setAttribute(PDO::ATTR_ERRMODE,
PDO::ERRMODE_EXCEPTION);
 echo "Connected successfully";
 } catch (PDOException $e) {
 echo "Connection failed: " . $e->getMessage();
 }
 $Course_code = $_GET["Course_code"];
 $Course_Title = $_GET["Course_Title"];
 $Credit_hour = $_GET["Credit_hour"];
 
 $conn->query("insert into courses values(' $Course_code ',' $Course_Title ',' $Credit_hour')");

 
?>
</p>
<p>Go <a href="/student/Course.php">back</a> to the
form</p>
<?php }
else { ?>
 <h2>Course Registration Form</h2>
 <form action="Course.php" method="GET">
 Course_code:
 <input type="text" placeholder="Course_code"
name="Course_code">
<br> Course_Title:
 <input type="text" placeholder="Course_Title"
name="Course_Title">
 <br> Credit:
 <input type="text" placeholder="Credit_hour"
name="Credit_hour">

 <input type="hidden" name="form_submitted"
value="1" />
 <br>
 <input type="submit" value="Submit">
 </form>
<?php } ?>
</body>
</html>