# student-registration-system

This project is simple student registration system. It has basically different admins but at the same time one can login.
It has root level access ai can create more admin account. It takes username and password. First password is generated in the mysql.

It can view the list of the students.
It can edit the record.
Delete The record.

Registered the courses but these courses are for class not for a particuler person and all the courses would be same for all the students.
He can watch the register courses.

We use PHP bootstrap and mysql for this project.
For this XAMPP is used for running this project.

Username : 18P-0041
Password : alee12